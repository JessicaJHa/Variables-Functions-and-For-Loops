#create a funtion that changes the weight of an ice cube(sphere) to diameter
weights=c(0.96, 1.51, 2.17, 3.85, 4.45, 6.02)
diam=function(w){(2/2.54)*(w/(0.92*(4/3)*pi)^.33333)}
for(w in weights){
  d=diam(w)
  cat(w," grams= ",d, " inches\n")
  
}
for (weight in weights){d = diam(weight)
cat(w, "grams =", d)}